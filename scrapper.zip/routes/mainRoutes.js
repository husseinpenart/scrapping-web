const { Router } = require("express");
const { authenticated } = require("../middleware/auth");
const { adsControllers } = require("../controllers/mainpage");
const divarModal = require("../model/robotModel");
const { formatDate } = require("../utils/jalalis");
const router = new Router();
const Watcher = require('../model/Watcher');

router.get("/adsPost", async (req, res) => {
  const page = +req.query.page || 1;
  const postPerPage = 1;

  try {
    const numberOfPosts = await divarModal.find({}).countDocuments();
    const blogs = await divarModal 
      .find({})
      .sort({ createdAt: "desc" })
      .skip((page - 1) * postPerPage)
      .limit(postPerPage);

    res.render("adsPost", {
      pageTitle: "بخش مدیریت | داشبورد",
      path: "/adsPost",
      blogs,
      formatDate,
      currentPage: page,
      nextPage: page + 1,
      previousPage: page - 1,
      hasNextPage: postPerPage * page < numberOfPosts,
      hasPreviousPage: page > 1,
      lastPage: Math.ceil(numberOfPosts / postPerPage),
      numberOfPosts,
    
     
    });
  } catch (err) {
    console.log(err);
  }
});

router.get("/singlePage/:id", async (req, res) => {
  try {
    const post = await divarModal.findOne({ _id: req.params.id }).populate();

    if (!post) return res.redirect("/404");

    res.render("singlePage", {
      pageTitle: post.title,
      path: "/singlePage",
      post,
      formatDate,
      
    });
  } catch (err) {
    console.log(err);
  }
});
router.post('/singlePage/:id', async (req, res) => {

    var body  = req.body
  try {
    divarModal.find({}, (err, files) => {
      var newFile = new Watcher(body);
      newFile.save().then(doc => {
          res.redirect('/users/adsPost');
      }).catch(err => console.log(err));
    divarModal.find({}, (err, files) => {
      var newFile = new divarModal(body);
      newFile.save().then(doc => {
          res.redirect('/users/adsPost');
      }).catch(err => console.log(err));
  });
  });
      
  }
  catch (error) {
      res.status(400).json({message: error.message})
  }
})

module.exports = router;

