const { Router } = require("express");
const router = new Router()
router.get('/robot', (req, res) => {
    const robot = require('../assets/js/robot.js')

    res.render('robot', {
        path: '/robot',
        robot
    })
})


module.exports = router;
