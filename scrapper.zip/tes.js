const fs = require('fs');
const puppeteer = require('puppeteer');
const { scrollPageToBottom } = require('puppeteer-autoscroll-down')
const cheerio = require("cheerio");
const path  = require('path')

async function scrapeListing(page) {
  await page.goto(
    "https://divar.ir/s/tehran/real-estate/abshar-tehran?districts=306%2C1031%2C161%2C162%2C311%2C1034%2C165%2C1030%2C163%2C909%2C908&user_type=personal&sort=sort_date"
  );

  const html = await page.content();
  const j = await cheerio.load(html);

  const list = j(".kt-col-xxl-4-e9d46")
    .map((index, element) => {
      const titleElement = j(element).find("a");
      const title = j(
        "#app > div.kt-col-md-12-d59e3.browse-c7458 > main > div:nth-child(3) > div > div > div > div:nth-child(2) > a > article > div > div.kt-post-card__info > h2"
      ).text();
      const description = j(".kt-post-card__description").text();
      const url = "https://divar.ir" + j(titleElement).attr("href");
    const mainImg =  j('#post-list-container-id > div > div').map((i,el)=>{
        const img = j(el).find('#post-list-container-id > div > div > div > div:nth-child(2) > a > article > div > div.kt-post-card-thumbnail > div:nth-child(1) > picture > img').attr('data-src')
       })
      console.log(mainImg)
      return { title, url, description, mainImg };
    })
    .get();

  return list;
}
const Path = "C:/Program Files/Google/Chrome/Application/chrome.exe";

async function main() {

  const browser = await puppeteer.launch({
    headless: false,
    defaultViewport: false,
    executablePath: Path,
  });
  const page = await browser.newPage();

  
  const listing = await scrapeListing(page);
  const listWithOtherItem = await scrapeOtherItem(page, listing);
  console.log(listWithOtherItem);

}
main()
