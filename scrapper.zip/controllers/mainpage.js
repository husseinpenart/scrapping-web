const divarModal = require('../model/robotModel')


exports.getAds = async (req, res) => {
    try {

        await divarModal.studentValidation(req.body)
       
        const students = await divarModal.find().sort({createdAt: "desc"})
        res.render("adsPost", {
            windowTitle: "لیست فایل ها",
            path: "/adsPost",
            students,
            FormatDate,
           
            

        });
    } catch (err) {
        console.log(err);

    }
};
