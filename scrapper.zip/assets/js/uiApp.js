// var form = document.getElementById("form");

// form.addEventListener("submit", function (e) {
//   e.preventDefault();

//   var ownerName = document.getElementById("ownerName").value;
//   var constPhone = document.getElementById("constPhone").value;
//   var phone = document.getElementById("phone").value;
//   var elevator2 = document.querySelector("#elevator2").value;

//   var date = document.getElementById("date").value;
//   var type = document.getElementById("type").value;
//   var state = document.getElementById("state").value;
//   var meterage = document.getElementById("meterage").value;
//   var bedroom = document.getElementById("bedroom").value;
//   var floor = document.getElementById("floor").value;
//   var numOfFloors = document.getElementById("numOfFloors").value;
//   var unit = document.getElementById("unit").value;
//   var buildAge = document.getElementById("buildAge").value;
//   var parking = document.getElementById("parking").value;
//   var warehouse = document.getElementById("warehouse").value;
//   var elevator = document.getElementById("elevator").value;
//   var kitchen = document.getElementById("kitchen").value;
//   var view = document.getElementById("view").value;
//   var floortype = document.getElementById("floortype").value;
//   var service = document.getElementById("service").value;
//   var heatingAndCoolingSystem = document.getElementById(
//     "heatingAndCoolingSystem"
//   ).value;

//   var options = document.getElementById("options").value;
//   var price = document.getElementById("price").value;
//   var area = document.getElementById("area").value;
//   var fullPrice = document.getElementById("fullPrice").value;
//   var role = document.getElementById("role").value;
//   var advertiser = document.getElementById("advertiser").value;
//   var lone = document.getElementById("lone").value;
//   var changable = document.getElementById("changable").value;
//   var discount = document.getElementById("discount").value;
//   var documentState = document.getElementById("documentState").value;
//   var transfer = document.getElementById("transfer").value;

//   let rawdata = fs.readFileSync(path.join(pathName, "estate.json"));
//   let estates = JSON.parse(rawdata);
//   const specialpart = estates.estate.code;
//   var creatorCode = (document.getElementById("estatefileid").textContent =
//     specialpart);

//   let create = fs.readFileSync(path.join(pathName, "estate.json"));
//   let createId = JSON.parse(create);
//   const creating = createId.estate.code;
//   var creatorID = (document.getElementById("estatefileid").textContent =
//     creating);

// let useridc = fs.readFileSync(path.join(pathName, "estate.json"));
// let useridno = JSON.parse(useridc);
// const useridcreate = useridno.estate.normalUserIDs;
// var normalUserIDs = (document.getElementById("normaluserId").textContent =
// useridcreate);
// console.log(normalUserIDs)
   
//   fetch("http://fileestore.ir/api/add-file", {
//     method: "POST",
//     body: JSON.stringify({
//       ownerName: ownerName,
//       constPhone: constPhone,
//       phone: phone,
//       date: date,
//       type: type,
//       state: state,
//       elevator2: elevator2,
//       meterage: meterage,
//       bedroom: bedroom,
//       floor: floor,
//       numOfFloors: numOfFloors,
//       unit: unit,
//       buildAge: buildAge,
//       parking: parking,
//       warehouse: warehouse,
//       elevator: elevator,
//       kitchen: kitchen,
//       view: view,
//       floortype: floortype,
//       service: service,
//       heatingAndCoolingSystem: heatingAndCoolingSystem,
//       options: options,
//       price: price,
//       area: area,
//       fullPrice: fullPrice,
//       role: role,
//       advertiser: advertiser,
//       lone: lone,
//       changable: changable,
//       discount: discount,
//       documentState: documentState,
//       transfer: transfer,
//       creatorCode: creatorCode,
//       creatorID: creatorID,
//       normalUserIDs:normalUserIDs

//     }),
//     headers: {
//       "Content-type": "application/json; charset=UTF-8",
//       "Cookie" : "sid=s%3AMEztr1S8tYfsTeWi2ood21P_MirHEVOd.2%2FWlXNrM6uoHbPW2Xy8x5n4G25H9ZXhxYvKcPFeFPhI"
//     },
//   })
//     .then(function (response) {
//       return response.json();
//     })
//     .then(function (data) {
//       document.getElementById("form").reset();
//       console.log(data.normalUserIDs);

//       getData();
//       if (data) {
//       console.log('successfully added')
        
//       }
//     })
//     .catch((error) => console.error("Error:", error));
// });



