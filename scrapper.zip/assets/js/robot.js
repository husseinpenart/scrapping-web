const puppeteer = require("puppeteer");
const cheerio = require("cheerio");
const jsdom = require("jsdom");
const { JSDOM } = jsdom;
const { window } = new JSDOM();
const { document } = new JSDOM("").window;
const { pageExtend } = require("puppeteer-jquery");
const fs = require("fs").promises;
const connectDB = require('../../db/connection');
const $ = (jQuery = require("jquery")(window));
const { scrollPageToBottom } = require('puppeteer-autoscroll-down')

const mongoose = require("mongoose");
const schedule = require("node-schedule");
const divarModal = require("../../model/robotModel");
connectDB()

async function scrapeListing(page) {
  await page.goto(
    "https://divar.ir/s/tehran/real-estate/abshar-tehran?districts=306%2C1031%2C161%2C162%2C311%2C1034%2C165%2C1030%2C163%2C909%2C908&user_type=personal&sort=sort_date"
    );
    await sleep(35000)
  const html = await page.content();
  const j = await cheerio.load(html);
  
  const list = j(".kt-col-xxl-4-e9d46")
    .map((index, element) => {
      const titleElement = j(element).find("a");
      const title = j(
        "#app > div.kt-col-md-12-d59e3.browse-c7458 > main > div:nth-child(3) > div > div > div > div:nth-child(2) > a > article > div > div.kt-post-card__info > h2"
      ).text();
      const description = j(".kt-post-card__description").text();
      const url = "https://divar.ir" + j(titleElement).attr("href");
    const mainImg =  $('#post-list-container-id > div > div').map((i,el)=>{
        const img = $(el).find('#post-list-container-id > div > div > div > div:nth-child(2) > a > article > div > div.kt-post-card-thumbnail > div:nth-child(1) > picture > img').attr('data-src')
       })
      console.log(mainImg)
      return { title, url, description, mainImg };
    })
    .get();

  return list;
}

async function scrapeOtherItem(page, listing) {
  await sleep(3000)
  const result = [];


  for (let i = 0; i <= listing.length; i++) {
    await page.goto(listing[i].url);
    const html = await page.content();
    const j = await cheerio.load(html);
   
    try {
     //توی بخش اول میره تک صفحه هایی که دکمه  دارن رو میگیره اگر بود اطلاعات رو میگیره نبود میره سراغ بخش فاینال من توضییحات بیشتر رو توی یه فایل مجزا براتون گذاشتم
      await page.click('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div.raw-button-cd669 > div > div > div.kt-base-row__start > p')
      
      await sleep(5000);
      const strategy = j(
        ".kt-page-title__title .kt-page-title__title--responsive-sized"
      ).text();
  
      const titlemain = j(".kt-page-title__title--responsive-sized").text();
      const description = j(
        "#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(5) > div.kt-base-row.kt-base-row--large.kt-description-row > div > p"
      ).text();
      const phone = j(
        "#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div.expandable-box > div.copy-row > div"
      ).text();
      console.log(phoneNumber)
      const images = [];
      j(".kt-carousel__slide-container").map((i, el) => {
        const link = j(el).find("img").attr("src");
        images.push({
          link,
        });
      });
      const category = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(6)').text()
      const address = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div.kt-page-title > div > div.kt-page-title__subtitle.kt-page-title__subtitle--responsive-sized').text()
      const meterage = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(1) > div:nth-child(1) > span.kt-group-row-item__value').text() 
      const buildAge = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(1) > div:nth-child(2) > span.kt-group-row-item__value').text() 
      const bedroom = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(1) > div:nth-child(3) > span.kt-group-row-item__value').text() 
      const fullPrice = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(3) > div.kt-base-row__end.kt-unexpandable-row__value-box > p').text() 
      const price = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(5) > div.kt-base-row__end.kt-unexpandable-row__value-box > p').text() 
      const floor = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(7) > div.kt-base-row__end.kt-unexpandable-row__value-box > p').text() 
      const elevator = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(10) > div:nth-child(1) > span').text() 
      const parking = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(10) > div:nth-child(2) > span').text() 
      const warehouse = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(10) > div:nth-child(3) > span').text() 
      const unit = j('body > div.kt-dimmer.kt-dimmer--darker.kt-dimmer--open > div > div > div > div > div:nth-child(2) > div.kt-base-row__end.kt-unexpandable-row__value-box > p').text() 
      const view = j('body > div.kt-dimmer.kt-dimmer--darker.kt-dimmer--open > div > div > div > div > div:nth-child(6) > div.kt-base-row__end.kt-unexpandable-row__value-box > p').text() 
      const options = j('body > div.kt-dimmer.kt-dimmer--darker.kt-dimmer--open > div > div > div > div > div:nth-child(17) > div > p').text() 
      const floortype = j('body > div.kt-dimmer.kt-dimmer--darker.kt-dimmer--open > div > div > div > div > div:nth-child(19) > div > p').text() 
      const service = j('body > div.kt-dimmer.kt-dimmer--darker.kt-dimmer--open > div > div > div > div > div:nth-child(21) > div > p').text() 
      const heatingAndCoolingSystem = j('body > div.kt-dimmer.kt-dimmer--darker.kt-dimmer--open > div > div > div > div > div:nth-child(23) > div > p').text() 
      const heatingAndCoolingSystem2 = j('body > div.kt-dimmer.kt-dimmer--darker.kt-dimmer--open > div > div > div > div > div:nth-child(25) > div > p').text() 
      const adsStatus = j('').text() 
      const area = j('').text() 
      const ownerName = j('').text() 
      const constPhone = j('').text() 
      const type = j('').text() 
      const date = j('').text() 
      const dateJ = j('').text() 
      const state = j('').text() 
      const fileNumber = j('').text() 
      const role = j('').text() 
      const numOfFloors = j('').text() 
      const meterage2 = j('').text() 
      const bedroom2 = j('').text() 
      const floor2 = j('').text() 
      const numOfFloors2 = j('').text() 
      const unit2 = j('').text() 
      const buildAge2 = j('').text() 
      const parking2 = j('').text() 
      const warehouse2 = j('').text() 
      const elevator2 = j('').text() 
      const kitchen2 = j('').text() 
      const view2 = j('').text() 
      const floortype2 = j('').text() 
      const service2 = j('').text() 
      const meterage3 = j('').text() 
      const bedroom3 = j('').text() 
      const floor3 = j('').text() 
      const numOfFloors3 = j('').text() 
      const unit3 = j('').text() 
      const buildAge3 = j('').text() 
      const parking3 = j('').text() 
      const warehouse3 = j('').text() 
      const elevator3 = j('').text() 
      const kitchen3 = j('').text() 
      const view3 = j('').text() 
      const floortype3 = j('').text() 
      const service3 = j('').text() 
      const heatingAndCoolingSystem3 = j('').text() 
      const lone = j('').text() 
      const changable = j('').text() 
      const discount = j('').text() 
      const documentState = j('').text() 
      const transfer = j('').text() 
      const advertiser = j('').text() 
      const fileID = j('').text() 
      const mainImg = j('#post-list-container-id > div > div > div > div:nth-child(3) > a > article > div > div.kt-post-card-thumbnail > div:nth-child(1) > picture > img').attr('src')
  
      listing[i].titlemain = titlemain;
      listing[i].description = description;
      listing[i].strategy = strategy;
      listing[i].images = images;
      listing[i].phone = phone;                         
      listing[i].mainImg = mainImg;                         
      listing[i].category = category;
      listing[i].address = address;
      listing[i].meterage = meterage;
      listing[i].buildAge = buildAge;
      listing[i].bedroom = bedroom;
      listing[i].fullPrice = fullPrice;
      listing[i].adsStatus = adsStatus;
      listing[i].price = price;
      listing[i].floor = floor;
      listing[i].elevator = elevator;
      listing[i].parking = parking;
      listing[i].warehouse = warehouse;
      listing[i].unit = unit;
      listing[i].options = options;
      listing[i].floortype = floortype;
      listing[i].service = service;
      listing[i].heatingAndCoolingSystem = heatingAndCoolingSystem;
      listing[i].heatingAndCoolingSystem2 = heatingAndCoolingSystem2;
      listing[i].view = view;
      listing[i].area = area;
      listing[i].ownerName = ownerName;
      listing[i].constPhone = constPhone;
      listing[i].type = type;
      listing[i].date = date;
      listing[i].dateJ = dateJ;
      listing[i].state = state;
      listing[i].fileNumber = fileNumber;
      listing[i].role = role;
      listing[i].numOfFloors = numOfFloors;
      listing[i].meterage2 = meterage2;
      listing[i].bedroom2 = bedroom2;
      listing[i].floor2 = floor2;
      listing[i].numOfFloors2 = numOfFloors2;
      listing[i].unit2 = unit2;
      listing[i].buildAge2 = buildAge2;
      listing[i].parking2 = parking2;
      listing[i].warehouse2 = warehouse2;
      listing[i].elevator2 = elevator2;
      listing[i].kitchen2 = kitchen2;
      listing[i].view2 = view2;
      listing[i].floortype2 = floortype2;
      listing[i].service2 = service2;
      listing[i].meterage3 = meterage3;
      listing[i].bedroom3 = bedroom3;
      listing[i].floor3 = floor3;
      listing[i].numOfFloors3 = numOfFloors3;
      listing[i].unit3 = unit3;
      listing[i].buildAge3 = buildAge3;
      listing[i].parking3 = parking3;
      listing[i].warehouse3 = warehouse3;
      listing[i].elevator3 = elevator3;
      listing[i].kitchen3 = kitchen3;
      listing[i].floortype3 = floortype3;
      listing[i].service3 = service3;
      listing[i].heatingAndCoolingSystem3 = heatingAndCoolingSystem3;
      listing[i].lone = lone;
      listing[i].changable = changable;
      listing[i].discount = discount;
      listing[i].documentState = documentState;
      listing[i].transfer = transfer;
      listing[i].advertiser = advertiser;
      listing[i].fileID = fileID;
      listing[i].view3 = view3;
     
  
      console.log(listing[i]);
      result.push(listing[i]);
  
      // const cookies = await page.cookies();
      // await fs.writeFile('./cookies.json', JSON.stringify(cookies, null, 2));
  
      // const cookiesString = await fs.readFile("./cookies.json");
      // const cookie = JSON.parse(cookiesString);
      // await page.setCookie(...cookie);
      await sleep(3000);
      const model = new divarModal({
        title: listing[i].title,
        description: listing[i].description,
        url: listing[i].url,
        strategy: listing[i].strategy,
        titlemain: listing[i].titlemain,
        images: listing[i].images,
        phone: listing[i].phone,
        mainImg: listing[i].mainImg,
        category: listing[i].category,
        address: listing[i].address,
        meterage: listing[i].meterage,
        buildAge: listing[i].buildAge,
        bedroom: listing[i].bedroom,
        fullPrice: listing[i].fullPrice,
        price: listing[i].price,
        floor: listing[i].floor,
        parking: listing[i].parking,
        unit: listing[i].unit,
        floortype: listing[i].floortype,
        service: listing[i].service,
        heatingAndCoolingSystem: listing[i].heatingAndCoolingSystem,
        heatingAndCoolingSystem2: listing[i].heatingAndCoolingSystem2,
        view: listing[i].view,
        warehouse: listing[i].warehouse,
        elevator: listing[i].elevator,
        status: listing[i].status,
        area: listing[i].area,
        ownerName: listing[i].ownerName,
        adsStatus: listing[i].adsStatus,
        constPhone: listing[i].constPhone,
        type: listing[i].type,
        date: listing[i].date,
        dateJ: listing[i].dateJ,
        state: listing[i].state,
        fileNumber: listing[i].fileNumber,
        role: listing[i].role,
        numOfFloors: listing[i].numOfFloors,
        meterage2: listing[i].meterage2,
        bedroom2: listing[i].bedroom2,
        floor2: listing[i].floor2,
        numOfFloors2: listing[i].numOfFloors2,
        unit2: listing[i].unit2,
        buildAge2: listing[i].buildAge2,
        parking2: listing[i].parking2,
        warehouse2: listing[i].warehouse2,
        elevator2: listing[i].elevator2,
        kitchen2: listing[i].kitchen2,
        view2: listing[i].view2,
        floortype2: listing[i].floortype2,
        service2: listing[i].service2,
        meterage3: listing[i].meterage3,
        bedroom3: listing[i].bedroom3,
        numOfFloors3: listing[i].numOfFloors3,
        unit3: listing[i].unit3,
        buildAge3: listing[i].buildAge3,
        parking3: listing[i].parking3,
        warehouse3: listing[i].warehouse3,
        elevator3: listing[i].elevator3,
        kitchen3: listing[i].kitchen3,
        floortype3: listing[i].floortype3,
        service3: listing[i].service3,
        heatingAndCoolingSystem3: listing[i].heatingAndCoolingSystem3,
        lone: listing[i].lone,
        changable: listing[i].changable,
        discount: listing[i].discount,
        documentState: listing[i].documentState,
        transfer: listing[i].transfer,
        advertiser: listing[i].advertiser,
        fileID: listing[i].fileID,
        view3: listing[i].view3,
  
      });
  
      await model.save();
      await sleep(3000);
    

    } catch (error) {
     console.log(error)
    }finally{
      const strategy = j(
        ".kt-page-title__title .kt-page-title__title--responsive-sized"
      ).text();
  
      const titlemain = j(".kt-page-title__title--responsive-sized").text();
      const description = j(
        "#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(5) > div.kt-base-row.kt-base-row--large.kt-description-row > div > p"
      ).text();
      const phone = j(
        "#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div.expandable-box > div.copy-row > div"
      ).text();
      const images = [];
      j(".kt-carousel__slide-container").map((i, el) => {
        const link = j(el).find("img").attr("src");
        images.push({
          link,
        });
      });
      const category = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(6)').text()
      const address = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div.kt-page-title > div > div.kt-page-title__subtitle.kt-page-title__subtitle--responsive-sized').text()
      const meterage = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(1) > div:nth-child(1) > span.kt-group-row-item__value').text() 
      const buildAge = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(1) > div:nth-child(2) > span.kt-group-row-item__value').text() 
      const bedroom = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(1) > div:nth-child(3) > span.kt-group-row-item__value').text() 
      const fullPrice = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(3) > div.kt-base-row__end.kt-unexpandable-row__value-box > p').text() 
      const price = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(5) > div.kt-base-row__end.kt-unexpandable-row__value-box > p').text() 
      const floor = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(7) > div.kt-base-row__end.kt-unexpandable-row__value-box > p').text() 
      const elevator = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(10) > div:nth-child(1) > span').text() 
      const parking = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(10) > div:nth-child(2) > span').text() 
      const warehouse = j('#app > div.container--has-footer-d86a9.kt-container > div > div.kt-row > div.kt-col-5 > div:nth-child(4) > div:nth-child(10) > div:nth-child(3) > span').text() 
      const unit = j('body > div.kt-dimmer.kt-dimmer--darker.kt-dimmer--open > div > div > div > div > div:nth-child(2) > div.kt-base-row__end.kt-unexpandable-row__value-box > p').text() 
      const view = j('body > div.kt-dimmer.kt-dimmer--darker.kt-dimmer--open > div > div > div > div > div:nth-child(6) > div.kt-base-row__end.kt-unexpandable-row__value-box > p').text() 
      const options = j('body > div.kt-dimmer.kt-dimmer--darker.kt-dimmer--open > div > div > div > div > div:nth-child(17) > div > p').text() 
      const floortype = j('body > div.kt-dimmer.kt-dimmer--darker.kt-dimmer--open > div > div > div > div > div:nth-child(19) > div > p').text() 
      const service = j('body > div.kt-dimmer.kt-dimmer--darker.kt-dimmer--open > div > div > div > div > div:nth-child(21) > div > p').text() 
      const heatingAndCoolingSystem = j('body > div.kt-dimmer.kt-dimmer--darker.kt-dimmer--open > div > div > div > div > div:nth-child(23) > div > p').text() 
      const heatingAndCoolingSystem2 = j('body > div.kt-dimmer.kt-dimmer--darker.kt-dimmer--open > div > div > div > div > div:nth-child(25) > div > p').text() 
      const mainImg = j('#post-list-container-id > div > div > div > div:nth-child(3) > a > article > div > div.kt-post-card-thumbnail > div:nth-child(1) > picture > img').attr('src')
      const adsStatus = j('').text() 
      const area = j('').text() 
      const ownerName = j('').text() 
      const constPhone = j('').text() 
      const type = j('').text() 
      const date = j('').text() 
      const dateJ = j('').text() 
      const state = j('').text() 
      const fileNumber = j('').text() 
      const role = j('').text() 
      const numOfFloors = j('').text() 
      const meterage2 = j('').text() 
      const bedroom2 = j('').text() 
      const floor2 = j('').text() 
      const numOfFloors2 = j('').text() 
      const unit2 = j('').text() 
      const buildAge2 = j('').text() 
      const parking2 = j('').text() 
      const warehouse2 = j('').text() 
      const elevator2 = j('').text() 
      const kitchen2 = j('').text() 
      const view2 = j('').text() 
      const floortype2 = j('').text() 
      const service2 = j('').text() 
      const meterage3 = j('').text() 
      const bedroom3 = j('').text() 
      const floor3 = j('').text() 
      const numOfFloors3 = j('').text() 
      const unit3 = j('').text() 
      const buildAge3 = j('').text() 
      const parking3 = j('').text() 
      const warehouse3 = j('').text() 
      const elevator3 = j('').text() 
      const kitchen3 = j('').text() 
      const view3 = j('').text() 
      const floortype3 = j('').text() 
      const service3 = j('').text() 
      const heatingAndCoolingSystem3 = j('').text() 
      const lone = j('').text() 
      const changable = j('').text() 
      const discount = j('').text() 
      const documentState = j('').text() 
      const transfer = j('').text() 
      const advertiser = j('').text() 
      const fileID = j('').text() 
  
  
      listing[i].titlemain = titlemain;
      listing[i].description = description;
      listing[i].strategy = strategy;
      listing[i].images = images;
      listing[i].phone = phone;                         
      listing[i].mainImg = mainImg;                         
      listing[i].constPhone = constPhone;                         
      listing[i].category = category;
      listing[i].address = address;
      listing[i].meterage = meterage;
      listing[i].buildAge = buildAge;
      listing[i].bedroom = bedroom;
      listing[i].fullPrice = fullPrice;
      listing[i].adsStatus = adsStatus;
      listing[i].price = price;
      listing[i].floor = floor;
      listing[i].elevator = elevator;
      listing[i].parking = parking;
      listing[i].warehouse = warehouse;
      listing[i].unit = unit;
      listing[i].options = options;
      listing[i].floortype = floortype;
      listing[i].service = service;
      listing[i].heatingAndCoolingSystem = heatingAndCoolingSystem;
      listing[i].heatingAndCoolingSystem2 = heatingAndCoolingSystem2;
      listing[i].view = view;
      listing[i].area = area;
      listing[i].ownerName = ownerName;
      listing[i].constPhone = constPhone;
      listing[i].type = type;
      listing[i].date = date;
      listing[i].dateJ = dateJ;
      listing[i].state = state;
      listing[i].fileNumber = fileNumber;
      listing[i].role = role;
      listing[i].numOfFloors = numOfFloors;
      listing[i].meterage2 = meterage2;
      listing[i].bedroom2 = bedroom2;
      listing[i].floor2 = floor2;
      listing[i].numOfFloors2 = numOfFloors2;
      listing[i].unit2 = unit2;
      listing[i].buildAge2 = buildAge2;
      listing[i].parking2 = parking2;
      listing[i].warehouse2 = warehouse2;
      listing[i].elevator2 = elevator2;
      listing[i].kitchen2 = kitchen2;
      listing[i].view2 = view2;
      listing[i].floortype2 = floortype2;
      listing[i].service2 = service2;
      listing[i].meterage3 = meterage3;
      listing[i].bedroom3 = bedroom3;
      listing[i].floor3 = floor3;
      listing[i].numOfFloors3 = numOfFloors3;
      listing[i].unit3 = unit3;
      listing[i].buildAge3 = buildAge3;
      listing[i].parking3 = parking3;
      listing[i].warehouse3 = warehouse3;
      listing[i].elevator3 = elevator3;
      listing[i].kitchen3 = kitchen3;
      listing[i].floortype3 = floortype3;
      listing[i].service3 = service3;
      listing[i].heatingAndCoolingSystem3 = heatingAndCoolingSystem3;
      listing[i].lone = lone;
      listing[i].changable = changable;
      listing[i].discount = discount;
      listing[i].documentState = documentState;
      listing[i].transfer = transfer;
      listing[i].advertiser = advertiser;
      listing[i].fileID = fileID;
      listing[i].view3 = view3;
     
  
      console.log(listing[i]);
      result.push(listing[i]);
  
      // const cookies = await page.cookies();
      // await fs.writeFile('./cookies.json', JSON.stringify(cookies, null, 2));
  
      // const cookiesString = await fs.readFile("./cookies.json");
      // const cookie = JSON.parse(cookiesString);
      // await page.setCookie(...cookie);
      await sleep(5000);
      const model = new divarModal({
        title: listing[i].title,
        description: listing[i].description,
        url: listing[i].url,
        strategy: listing[i].strategy,
        titlemain: listing[i].titlemain,
        images: listing[i].images,
        phone: listing[i].phone,
        mainImg: listing[i].mainImg,
        constPhone: listing[i].constPhone,
        category: listing[i].category,
        address: listing[i].address,
        meterage: listing[i].meterage,
        buildAge: listing[i].buildAge,
        bedroom: listing[i].bedroom,
        fullPrice: listing[i].fullPrice,
        price: listing[i].price,
        floor: listing[i].floor,
        parking: listing[i].parking,
        unit: listing[i].unit,
        floortype: listing[i].floortype,
        service: listing[i].service,
        heatingAndCoolingSystem: listing[i].heatingAndCoolingSystem,
        heatingAndCoolingSystem2: listing[i].heatingAndCoolingSystem2,
        view: listing[i].view,
        warehouse: listing[i].warehouse,
        elevator: listing[i].elevator,
        adsStatus: listing[i].adsStatus,
        area: listing[i].area,
        ownerName: listing[i].ownerName,
        status: listing[i].status,
        constPhone: listing[i].constPhone,
        type: listing[i].type,
        date: listing[i].date,
        dateJ: listing[i].dateJ,
        state: listing[i].state,
        fileNumber: listing[i].fileNumber,
        role: listing[i].role,
        numOfFloors: listing[i].numOfFloors,
        meterage2: listing[i].meterage2,
        bedroom2: listing[i].bedroom2,
        floor2: listing[i].floor2,
        numOfFloors2: listing[i].numOfFloors2,
        unit2: listing[i].unit2,
        buildAge2: listing[i].buildAge2,
        parking2: listing[i].parking2,
        warehouse2: listing[i].warehouse2,
        elevator2: listing[i].elevator2,
        kitchen2: listing[i].kitchen2,
        view2: listing[i].view2,
        floortype2: listing[i].floortype2,
        service2: listing[i].service2,
        meterage3: listing[i].meterage3,
        bedroom3: listing[i].bedroom3,
        numOfFloors3: listing[i].numOfFloors3,
        unit3: listing[i].unit3,
        buildAge3: listing[i].buildAge3,
        parking3: listing[i].parking3,
        warehouse3: listing[i].warehouse3,
        elevator3: listing[i].elevator3,
        kitchen3: listing[i].kitchen3,
        floortype3: listing[i].floortype3,
        service3: listing[i].service3,
        heatingAndCoolingSystem3: listing[i].heatingAndCoolingSystem3,
        lone: listing[i].lone,
        changable: listing[i].changable,
        discount: listing[i].discount,
        documentState: listing[i].documentState,
        transfer: listing[i].transfer,
        advertiser: listing[i].advertiser,
        fileID: listing[i].fileID,
        view3: listing[i].view3,
  
      });
  
      await model.save();
      await sleep(5000);
    }
  }
    return result;
}



async function sleep(miliseconds) {
  return new Promise((resolve) => setTimeout(resolve, miliseconds));
}
// function scheduler() {
//   const job = schedule.scheduleJob("20 16 * * *", () => {
//     main();
//   });
// }
const Path = "C:/Program Files/Google/Chrome/Application/chrome.exe";
async function main() {

  const browser = await puppeteer.launch({
    headless: false,
    defaultViewport: false,
    executablePath: Path,
  });
  const pageOrg = await browser.newPage();
  const page = pageExtend(pageOrg);
  
  const listing = await scrapeListing(page);
  const listWithOtherItem = await scrapeOtherItem(page, listing);
  console.log(listWithOtherItem);

  await divarModal.insertMany(listWithOtherItem);
}
main()
