const path = require("path");
const express = require("express");
const mongoose = require("mongoose");
const passport = require("passport");
const flash = require("connect-flash");
const session = require("express-session");
const MongoStore = require("connect-mongo")(session);
const connectDB = require("./db/connection");
//* Database connection
connectDB();

//* Passport Configuration
require("./config/passport");

const app = express();

//* View Engine
app.set("view engine", "ejs");
app.set("views", "components");

//* BodyPaser
app.use(express.urlencoded({ extended: false }));
app.use(express.json());


//* Session
app.use(
    session({
        secret: 'jifewjewoifewjoiwej-23',
        cookie: { maxAge: 600000 },
        resave: true,
        saveUninitialized: true,
        store: new MongoStore({ mongooseConnection: mongoose.connection }),
    })
);

//* Passport
app.use(passport.initialize());
app.use(passport.session());

//* Flash
app.use(flash()); //req.flash

//* Static Folder
app.use(express.static(path.join(__dirname, "./assets")));

//* Routes
app.use("/users", require("./routes/userRoute"));
app.use("/users", require("./routes/mainRoutes"));
app.use("/ads", require("./routes/robotRoutes"));

const corsOptions ={
   origin:'*', 
   credentials:true,           
   optionSuccessStatus:200,
}

//* 404 Page

const PORT = process.env.PORT || 3000;

app.listen(PORT, () =>
    console.log(
        `Server running in ${process.env.NODE_ENV} mode on port ${PORT}`
    )
);
