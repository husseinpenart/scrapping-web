const { app, BrowserWindow,Tray } = require('electron')
const path  = require('path');
const notifier = require('node-notifier')
let win
let tray
let AdsUrl
function MainPage() {
  win = new BrowserWindow({
      icon: './assets/image/logo.png',
      webPreferences: {
          // nodeIntegration: true,
          contextIsolation: false,
          enableRemoteModule: true
      }
  })
  win.maximize()
  win.show()
  // win.resizable = false
  win.loadURL('http://localhost:3000/users/login')

  win.webContents.openDevTools()
  tray = new Tray('./assets/image/logo.png')
  tray.setToolTip('سیستم هوشمند فایل استور ')
  tray.on('click', () => {
      if (win.isVisible()) {
          win.hide()
      } else {
          win.show()
      }
  })


}
notifier.notify(
  {
    title: 'سلام کاربر محترم',
    message: 'به نرم افزار هوشمند فایل استور خوش آمدید',
    icon: path.join(__dirname, './assets/image/logo.png'), 
    sound: true,
    
  },

);


function Linking (){
  AdsUrl = new BrowserWindow({
    icon: './assets/image/logo.png',
    webPreferences: {
        // nodeIntegration: true,
        contextIsolation: false,
        enableRemoteModule: true
    }
})
AdsUrl.maximize()
AdsUrl.show()
}
app.on('ready' , ()=>{
  Linking()
})
app.on('ready',()=>{
  MainPage()
  notifier
    
})